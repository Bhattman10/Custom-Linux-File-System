#define FUSE_USE_VERSION 26
#include <iostream>
#include <stdlib.h>
#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <cstring> 
#include "../libWad/Wad.h"

static int wad_getattr(const char *path, struct stat *stbuf)
{
    memset(stbuf, 0, sizeof(struct stat));

    if(((Wad*)fuse_get_context()->private_data)->isContent(path))
    {
        stbuf->st_mode = S_IFREG | 0777;
        stbuf->st_nlink = 1;
        stbuf->st_size = ((Wad*)fuse_get_context()->private_data)->getSize(path);
        return 0;
    }
    else if(((Wad*)fuse_get_context()->private_data)->isDirectory(path))
    {

        stbuf->st_mode = S_IFDIR | 0755;
        stbuf->st_nlink = 2;
        return 0;
    }
    else
    {
        return -ENOENT;
    }
}

static int wad_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    // int length = ((Wad*)fuse_get_context()->private_data)->getContents(path, buf, size, offset);
    // if(length >= 0)
    // {
    //     return length;
    // }
    // else
    // {
    //     return -ENOENT;
    // }

    size_t len = ((Wad*)fuse_get_context()->private_data)->getSize(path);
    if (offset >= len) {
      return 0;
    }

    //create file content
    char filecontent[len];
    len = ((Wad*)fuse_get_context()->private_data)->getContents(path,filecontent,len);

    if (offset + size > len) {
      memcpy(buf, filecontent + offset, len - offset);
      return len - offset;
    }

    memcpy(buf, filecontent + offset, size);
    return size;
    
}

static int wad_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
    std::vector<std::string> list;
    int listLength = ((Wad*)fuse_get_context()->private_data)->getDirectory(path, &list);

    filler(buf, ".", NULL, 0 ); // Current Directory
	filler(buf, "..", NULL, 0 ); // Parent Directory

    for(int i = 0; i < list.size(); i++)
        {
            filler(buf, list[i].c_str(), NULL, 0);
        }
	
	return 0;
}

static int wad_write( const char *path, const char *buffer, size_t size, off_t offset, struct fuse_file_info *info )
{
    int length = ((Wad*)fuse_get_context()->private_data)->writeToFile(path, buffer, size, offset);
    if(length >= 0)
    {
        return length;
    }
    else
    {
        return -ENOENT;
    }
}

static int wad_mkdir( const char *path, mode_t mode )
{
	((Wad*)fuse_get_context()->private_data)->createDirectory(path);
	return 0;
}

static int wad_mknod( const char *path, mode_t mode, dev_t rdev )
{
    ((Wad*)fuse_get_context()->private_data)->createFile(path);
	return 0;
}

struct fuse_operations operations = {
    .getattr = wad_getattr,
    .mknod = wad_mknod,
    .mkdir = wad_mkdir,
    .read = wad_read,
    .write = wad_write,
    .readdir = wad_readdir
};

int main(int argc, char* argv[])
{
    if(argc < 3)
    {
        std::cout << "Not enough arguments." << std::endl;
        exit(EXIT_SUCCESS);
    }

    std::string wadPath = argv[argc - 2];

    if(wadPath.at(0) != '/')
    {
        wadPath = std::string(get_current_dir_name()) + "/" + wadPath;
    }
    Wad* myWad = Wad::loadWad(wadPath);

    argv[argc - 2] = argv[argc - 1];
    argc--;

    return fuse_main(argc, argv, &operations, myWad);
};

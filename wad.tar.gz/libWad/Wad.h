#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <vector>
#include <fstream> 
#include <stack>
#include <cctype>
#include <queue>
#include <sstream>
#include <string>
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <cstdint>

class Wad
{
private:

    //Wad constructor w/ path to wad file
    Wad(const std::string &path);
    //store wad path
    std::string wadPath;

    //fstream
    std::fstream file;
    //magic string
    std::string magicStr;
    //number of descriptors
    uint32_t numDesc;
    //descriptor offset
    uint32_t descOff;
    //current position to use w/ seekg functions
    uint32_t pos;

    //https://www.geeksforgeeks.org/generic-treesn-array-trees/#
    struct Node 
    {
        //data
        bool mapDir;
        bool nameStartDir;
        uint32_t lumpOffset;
        int lumpLength;
        std::string name;
        uint32_t indiNextDescOffset;
        uint32_t _ENDOffsetLoc;

        //pointers
        std::vector<Node*> children;

        //constructor
        Node(bool a, bool b, uint32_t c, int d, std::string e, uint32_t f)
        : mapDir(a), nameStartDir(b), lumpOffset(c), lumpLength(d), name(e), indiNextDescOffset(f){}
    };

    //n-array tree root
    Node* root = nullptr;
    //stack data structure to track the current directory
    std::stack<Node*> directoryStack;
    //curent directory pointer
    Node* currentDirectory;
    //curent Node pointer
    Node* currentNode;
    //queue for holding order of path names
    // std::queue<std::string> pathNames;

public:

    static Wad* loadWad(const std::string &path);
    std::string getMagic();
    bool isContent(const std::string &path);
    bool isDirectory(const std::string &path);
    int getSize(const std::string &path);
    int getContents(const std::string &path, char *buffer, int length, int offset = 0);
    int getDirectory(const std::string &path, std::vector<std::string> *directory);
    void createDirectory(const std::string &path);
    void createFile(const std::string &path);
    int writeToFile(const std::string &path, const char *buffer, int length, int offset = 0);

    bool mapDirectoryChecker(const std::string& str);
    bool nameStartDirectoryChecker(const std::string& str);
    bool nameEndDirectoryChecker(const std::string& str);
    void addMapDirectoryFiles(Node* mapMarkerNode);
    std::string removeLastSixCharacters(const std::string& str);
    int countSlashes(const std::string& str);
    std::queue<std::string> loadPathNames(const std::string& str);
    bool loadPathNode(std::string path);
    bool pathChecker(std::string path);
    void updateWadTree(std::string wadPath);

    void printFileContentsTEST();

};
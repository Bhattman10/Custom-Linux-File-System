#include "Wad.h"

bool Wad::mapDirectoryChecker(const std::string& str)
{
    // Check if string is 4 characters long
    if (str.length() != 4) {
        return false;
    }

    // Check if the 1st and 3rd characters are letters
    if (!isalpha(str[0]) || !isalpha(str[2])) {
        return false;
    }

    // Check if the 2nd and 4th characters are numbers
    if (!isdigit(str[1]) || !isdigit(str[3])) {
        return false;
    }

    // All requirements are met
    return true;
}

bool Wad::nameStartDirectoryChecker(const std::string& str)
{
    // Check if string is at least 7 characters long
    if (str.length() < 7) {
        return false;
    }

    // Check if the last 6 characters are "_START"
    std::string endStr = str.substr(str.length() - 6);
    if (endStr == "_START") {
        return true;
    }

    // If not, return false
    return false;
}

std::string Wad::removeLastSixCharacters(const std::string& str)
{
    if (str.length() <= 6) {
        // If the string has 6 characters or less, return an empty string
        return "";
    } else {
        // Otherwise, return the substring from the beginning of the string up to the length minus 6
        return str.substr(0, str.length() - 6);
    }
}

bool Wad::nameEndDirectoryChecker(const std::string& str)
{
    // Check if string is at least 4 characters long
    if (str.length() < 4) {
        return false;
    }

    // Check if the last 4 characters are "_END"
    std::string endStr = str.substr(str.length() - 4);
    if (endStr == "_END") {
        return true;
    }

    // If not, return false
    return false;
}

void Wad::addMapDirectoryFiles(Node* mapMarkerNode)
{
    //update current directory with map marker directory
    directoryStack.push(mapMarkerNode);
    currentDirectory = directoryStack.top();

    //iterator to count next 10 files
    int filesLeft = 10;
    while(filesLeft > 0)
    {
        //go to next descriptor offset
        file.seekg(pos, std::ios::beg);

        //variables for storing fstream read values to create Node
        uint32_t elementOff; uint32_t elementLength;
        char name[8]; name[7] = '\0';

        //fill in variables using fstream
        file.read((char*)&elementOff, 4); file.read((char*)&elementLength, 4); file.read(name, 8);

        //convert name from char array to string
        std::string nameStr = name;

        //iterate the pos
        pos = pos + 16;

        //create Node with directory types, element offset, length & name
        currentNode = new Node(false, false, elementOff, elementLength, nameStr, pos);

        //testing
        // std::cout << "New Element (child of " << currentDirectory->name << ") w/ element offset = "
        // << elementOff << ", element length = " << elementLength << ", and name = " << nameStr << std::endl;

        //add newly created node to directory children list
        currentDirectory->children.push_back(currentNode);

        //iterate i
        filesLeft--;

    }

    //remove current directory from stack
    directoryStack.pop();

}

int Wad::countSlashes(const std::string& str)
{
    int count = 0;
    for (char c : str) {
        if (c == '/') {
            count++;
        }
    }
    return count;
}

std::queue<std::string> Wad::loadPathNames(const std::string& str)
{
    //queue for holding order of path names
    std::queue<std::string> pathNames;

    std::istringstream iss(str);
    std::string token;

    while (std::getline(iss, token, '/'))
    {
        pathNames.push(token);
    }

    return pathNames;
}

bool Wad::loadPathNode(std::string path)
{

    //boolean to indicate valid path
    bool validPath;

    //first, check how many '/' there are and record the number
    int slashes = countSlashes(path);

    // o.g.
    // //load names into queue
    // loadPathNames(path);

    //queue for holding order of path names
    std::queue<std::string> pathNames;
    pathNames = loadPathNames(path);

    //pop to remove newline
    pathNames.pop();

    //edge case: path is just the original directory ("/")
    if(slashes == 1 && pathNames.size() == 0)
    {
        currentNode = root;
        return true;
    }

    //set currentNode equal to root
    currentNode = root;

    //create a while loop that counts down based on the number of directories in the path
    while(slashes > 0)
    {
        //reset valid path for each token search
        validPath = false;

        //check if there is one slash left with no names in queue
        if(slashes == 1 && pathNames.size() == 0)
        {
            return true;
        }

        //passing string with next name in queue
        std::string nextName = pathNames.front();

        //search through the currentNodes children till you find the next name in the path
        for (Node* node : currentNode->children) {
            //compare names
            if (node->name == nextName)
            {
                currentNode = node;
                validPath = true;
                break;
            }
        }

        //if the for loop did not find a matching child, return false
        if(!validPath)
        {
            currentNode = nullptr;
            return false;
        }

        //pop name from queue
        pathNames.pop();

        //iterate slashes by subtracting 1
        slashes--;
    }

    return true;
}

bool Wad::pathChecker(std::string path)
{
    //case: path is empty
    if(path == "")
    {
        return false;
    }
    
    return true;
}

void Wad::updateWadTree(std::string wadPath)
{
    ///INIT FSTREAM OBJECT
    //Should initialize an fstream object and store it as a member variable.
    //Use it to read the header data.

    //Courtesy of Ernesto Mujica:

    file.seekg(0, std::ios::beg);

    //read and store magic
    char magic[5];
    magic[4] = '\0';
    file.read(magic, 4);
    magicStr = magic;

    //read and store the number of descriptors
    file.read((char*)&numDesc, 4);

    //read and store the descriptor offset
    file.read((char*)&descOff, 4);

    //iterate position
    pos = 12;

    ///CONSTRUCT N-ARY TREE
    //Construct your tree from the descriptor list. No need to read in lump data at this point

    //initialize root node
    root = new Node(true, true, 0, 0, "/", 0);

    //push root onto directory stack
    directoryStack.push(root);

    //set pos with descriptor offset
    pos = descOff;

    ///FILL IN N-ARY TREE

    //iterator to be decrement with each read of descriptor
    uint32_t descLeft = numDesc;
    
    //while loop that runs until all descriptors have been read
    while(descLeft > 0)
    {
        //assign current directory for assigning children
        currentDirectory = directoryStack.top();

        //go to next descriptor offset
        file.seekg(pos, std::ios::beg);

        //variables for storing fstream read values to create Node
        uint32_t elementOff; uint32_t elementLength;
        char name[8]; name[7] = '\0';

        //fill in variables using fstream
        file.read((char*)&elementOff, 4); file.read((char*)&elementLength, 4); file.read(name, 8);

        //iterate the pos
        pos = pos + 16;

        //subtract 1 from i, representing the descriptor that was just scanned
        descLeft--;

        //convert name from char array to string
        std::string nameStr = name;

        //check if element is a map marker directory
        bool mapMarker = mapDirectoryChecker(nameStr);

        //if map marker directory -> create node, add to current directory children vector,..
        //..and add next 10 files to map marker direcotry children
        if(mapMarker)
        {
            //create Node with directory types, element offset, length & name
            currentNode = new Node(true, false, elementOff, elementLength, nameStr, pos);

            //add newly created node to directory children list
            currentDirectory->children.push_back(currentNode);

            //add next 10 files to the children of currentNode
            addMapDirectoryFiles(currentNode);

            //subtract 10 from iterator to represent the 10 descriptors that were read from above
            descLeft = descLeft - 10;
        }
        //if not a map marker directory, check if namespace start/end directory, or normal file
        else
        {
            //check if element is a namespace start directory
            bool nameStartSpace = nameStartDirectoryChecker(nameStr);

            //if element marks start of directory -> create node, add to child vector, add directory to stack
            if(nameStartSpace)
            {
                //remove the directory tag from name
                std::string newName = removeLastSixCharacters(nameStr);

                //create Node with directory types, element offset, length & name
                currentNode = new Node(false, true, elementOff, elementLength, newName, pos);

                //add newly created node to directory children list
                currentDirectory->children.push_back(currentNode);

                directoryStack.push(currentNode);

            }
            //check if element marks the end of a directory, or if it's a normal file
            else
            {
                //check if element is a namespace end directory
                bool nameEndSpace = nameEndDirectoryChecker(nameStr);

                //if element marks end of directory, remove directory from stack
                if(nameEndSpace)
                {
                    //update the top element's _END offset location
                    directoryStack.top()->_ENDOffsetLoc = pos;
                    //remove top element (current directory) from stack
                    directoryStack.pop();
                }
                //element is a normal file
                else
                {
                    //create Node and add to current directory children list
                    //create Node with directory types, element offset, length & name
                    currentNode = new Node(false, false, elementOff, elementLength, nameStr, pos);

                    //testing
                    // std::cout << "New Element (child of " << currentDirectory->name << ") w/ element offset = "
                    // << elementOff << ", element length = " << elementLength << ", and name = " << nameStr << std::endl;

                    //add newly created node to directory children list
                    currentDirectory->children.push_back(currentNode);
                }
            }
        }
    }
}

void Wad::printFileContentsTEST()
{
    //testing!
    // Get the length of the file
    file.seekg(descOff, std::ios::end);
    std::streampos length = file.tellg();
    file.seekg(descOff, std::ios::beg);
    // Allocate a buffer to hold the entire file content
    std::string content;
    content.resize(length);
    // Read the entire file into the buffer
    file.read(&content[0], length);
    // Output the content of the file
    std::cout << "File content:\n" << content << std::endl;
}

//***** MAJOR FUNCTIONS *****//

//Object allocator; dynamically creates a Wad object and loads the WAD file data from path into memory.
//Caller must deallocate the memory using the delete keyword. 
Wad* Wad::loadWad(const std::string &path)
{
    Wad *wad = new Wad(path);
    return wad;
}

//Private constructor, takes in path to a .WAD file from your real filesystem. 
Wad::Wad(const std::string &path)
{
    ///INIT FSTREAM OBJECT
    //Should initialize an fstream object and store it as a member variable.
    //Use it to read the header data.
    wadPath = path;

    //Courtesy of Ernesto Mujica:
    file.open(path, std::ios::in | std::ios::out | std::ios::binary);

    //create first instance of wad tree
    updateWadTree(wadPath);
}

//Returns the magic for this WAD data.
std::string Wad::getMagic()
{
    return magicStr;
}

//Returns true if path represents content (data), and false otherwise. 
bool Wad::isContent(const std::string &path)
{
    //verify if path is empty string or not
    if(!pathChecker(path))
    {
        return false;
    }

    //set current node equal to final element along path
    bool validPath = loadPathNode(path);
    if(!validPath)
    {
        return false;
    }

    //check if currentNode is content
    if(currentNode->mapDir || currentNode->nameStartDir)
    {
        return false;
    }
    else
    {
        return true;
    }
}

//Returns true if path represents a directory, and false otherwise. 
bool Wad::isDirectory(const std::string &path)
{
    //verify if path is empty string or not
    if(!pathChecker(path))
    {
        return false;
    }

    //set current node equal to final element along path
    bool validPath = loadPathNode(path);
    if(!validPath)
    {
        return false;
    }

    //check if currentNode is content
    if(currentNode->mapDir || currentNode->nameStartDir)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//If path represents content, returns the number of bytes in its data; otherwise, returns -1. 
int Wad::getSize(const std::string &path)
{
    //verify if path is empty string or not
    if(!pathChecker(path))
    {
        return -1;
    }

    if(isContent(path))
    {
        //first, check how many '/' there are and record the number
        int slashes = countSlashes(path);

        //queue for holding order of path names
        std::queue<std::string> pathNames;

        //load names into queue
        pathNames = loadPathNames(path);

        //pop first name to remove newline
        pathNames.pop();

        //set currentNode equal to root
        currentNode = root;

        //create a while loop that counts down based on the number of directories in the path
        while(slashes > 0)
        {
            //assing string with next name in queue
            std::string nextName = pathNames.front();

            //search through the currentNodes children till you find the next name in the path
            for (Node* node : currentNode->children) {
                //compare names
                if (node->name == nextName)
                {
                    currentNode = node;
                    break;
                }
            }

            //pop name from queue
            pathNames.pop();

            //iterate slashes by subtracting 1
            slashes--;
        }

        return currentNode->lumpLength;

    }
    //path represents directory
    else
    {
        return -1;
    }
}

//If path represents content, copies as many bytes as are available, up to length, of content's data into the preexisting buffer.
//If offset is provided, data should be copied starting from that byte in the content.
//Returns number of bytes copied into buffer, or -1 if path does not represent content (e.g., if it represents a directory).
int Wad::getContents(const std::string &path, char *buffer, int length, int offset)
{
    //verify if path is empty string or not
    if(!pathChecker(path))
    {
        return -1;
    }

    //set currentNode equal to node referenced from path
    bool validPath = loadPathNode(path);
    if(!validPath)
    {
        return -1;
    }

    //check if given path leads to directory
    if(currentNode->mapDir == true || currentNode->nameStartDir == true)
    {
        return -1;
    }

    // //testing!
    // std::cout << "TESTING!!!!" << currentNode->lumpOffset << std::endl;

    //set position equal to lump offset + offset passed in parameter
    pos = currentNode->lumpOffset + offset;

    ///CHECK CASE AND PERFORM OEPRATIONS

    //verify the offset is less than lump length
    if(offset > currentNode->lumpLength)
    {
        return 0;
    }
    else if (offset == currentNode->lumpLength)
    {
        return 0;
    }

    //from beginning of file, go to start position to read file
    file.seekg(pos, std::ios::beg);

    //the amount of bytes read fits perfectly; read until the end
    if((currentNode->lumpLength - offset) == length)
    {
        //read length amount of bytes from start of offset
        file.read(buffer, length);

        //return the length amount of bytes read to buffer char array
        return length;
    }
    //read up to the length number of bytes
    else if((currentNode->lumpLength - offset) > length)
    {
        //read length amount of bytes from start of offset
        file.read(buffer, length);

        //return the length amount of bytes read to buffer char array
        return length;
    }
    //read up to the end of the element lump
    else if((currentNode->lumpLength - offset) < length)
    {   
        //read until end of lump from start of offset
        file.read(buffer, 100);

        //return the length amount of bytes read to buffer char array
        return (currentNode->lumpLength - offset);
    }
    
    return 0;
}

//If path represents a directory, places entries for immediately contained elements in directory.
//The elements should be placed in the directory in the same order as they are found in the WAD file.
//Returns the number of elements in the directory, or -1 if path does not represent a directory (e.g., if it represents content). 
int Wad::getDirectory(const std::string &path, std::vector<std::string> *directory)
{
    //verify if path is empty string or not
    if(!pathChecker(path))
    {
        return -1;
    }

    //set currentNode equal to node referenced from path
    bool validPath = loadPathNode(path);
    if(!validPath)
    {
        return -1;
    }

    //check if path leads to content instead of directory
    if(currentNode->mapDir == false && currentNode->nameStartDir == false)
    {
        return -1;
    }

    // Clear existing content of directory if any
    directory->clear();

    //iterate through directories children, pushing their names into the vector
    for (Node* node : currentNode->children)
    {
        directory->push_back(node->name);
    }

    size_t directorySize = directory->size();

    return directorySize;
}

//path includes the name of the new directory to be created. If given a valid path, creates a new directory
//using namespace markers at path. The two new namespace markers will be added just before the “_END”
//marker of its parent directory. New directories cannot be created inside map markers.
void Wad::createDirectory(const std::string &path)
{

    //return early if empty string passed through
    if(!pathChecker(path))
    {
        return;
    }
    //return early if just the root directory passed through
    if(path == "/")
    {
        return;
    }

    //1. seperate the path into 2 sections: old path and new directory

    //create variables that will hold the original path & new directory
    std::string originalPath; std::string newDir;

    //look for last appearanc of forward slash
    std::size_t found = path.find_last_of('/');

    //last appearance of forward-slash represents the last char of string
    if(found == path.length()-1)
    {
        //var to represent appended string if there is slash at the end
        std::string poppedBackPath;
        poppedBackPath = path;
        poppedBackPath.pop_back();
        found = poppedBackPath.find_last_of('/');
        //checker for if found location of slash is first char (aka root)
        if(found == 0)
        {
            originalPath = "/";
            newDir = poppedBackPath.substr(1);
        }
        else
        {
            originalPath = poppedBackPath.substr(0,found);
            newDir = poppedBackPath.substr(found+1);
        }
    }
    //last appearence of forward-slash preceded the new directory name
    else
    {
        originalPath = path.substr(0,found);
        newDir = path.substr(found+1);
    }
    //check if original path is empty
    if(originalPath.length() == 0)
    {
        originalPath = "/";
    }

    //verify if the name is 2 bytes or less in length
    if(newDir.length() > 2)
    {
        return;
    }

    //2. write new directory to file descriptor

    //load the currentNode with the directory that will hold the new directory
    bool success = loadPathNode(originalPath);
    if(!success)
    {
        return;
    }

    //position indicator for fstream
    int position;

    //find the last child of the parent directory
    currentDirectory = currentNode;
    //if the current directory has children... 
    if(currentDirectory->children.size() > 0)
    {
        //set the current node to the last child in the current directory.
        currentNode = currentDirectory->children.back();
        //and if the last child is a name space directory...
        if(currentNode->nameStartDir)
        {
            //...set the current position equal to the end of the _END offset location
            position = currentNode->_ENDOffsetLoc;
        }
        else
        {
            //...else set it equal to the next descriptor offset location
            position = currentNode->indiNextDescOffset;
        }
    }
    //else if the current directory is empty...
    else
    {
        //set the position equal to the next descriptor offset, b/c...
        //...the next directory will become a child of the current directory
        position = currentDirectory->indiNextDescOffset;
    }

    //2a. record everything from position to the end of the file

    //go to starting position in file
    file.seekg(position, std::ios::beg);

    //calculate the descriptor number we are about to start the copy at
    int descNum = (position - descOff)/16;
    //subtract number of descriptors from next descriptor number
    int difference = numDesc - descNum;
    //calculate the number of bytes required to be copied by mult. this number by 16
    int bytesToCopy = difference * 16;
    //create buffer to store copied data
    char descBuffer[bytesToCopy];
    if(bytesToCopy > 0)
    {
        file.read(descBuffer, bytesToCopy);
    }

    //2b. write the _START tag

    //create string for _START descriptor
    std::string start = newDir + "_START";
    char startChar[9];
    startChar[8] = '\0';
    strcpy(startChar, start.c_str());

    //variable to write zeros
    uint32_t zeros = 0;

    //write _START
    file.seekp(position, std::ios::beg);
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(start.c_str(), 8);

    //2c. write the _END tag

    //create string for _END descriptor
    std::string end = newDir + "_END";
    char endChar[9];
    endChar[8] = '\0';
    strcpy(endChar, end.c_str());

    //write _END
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(end.c_str(), 8);

    //write back the read content
    if(bytesToCopy > 0)
    {
        file.write(descBuffer, bytesToCopy);
    }

    //update the descriptor amount by adding 2
    file.seekp(4, std::ios::beg);
    uint32_t newNumberOfDescriptors = numDesc + 2;
    file.write(reinterpret_cast<const char*>(&newNumberOfDescriptors), 4);

    //update each descriptor located after the newly added descriptors
    root = nullptr;
    updateWadTree(wadPath);

}

//path includes the name of the new file to be created. If given a valid path, creates an empty file at path,
//with an offset and length of 0. The file will be added to the descriptor list just before the “_END” marker
//of its parent directory. New files cannot be created inside map markers.
void Wad::createFile(const std::string &path)
{
    //EARLY RETURNS (part1)
    //return early if empty string passed through
    if(!pathChecker(path))
    {
        return;
    }
    //return early if just the root directory passed through
    if(path == "/")
    {
        return;
    }

    //SECTION 1: SPLIT PATH INTO ORIGINAL PATH AND NEW FILE NAME

    //create variables that will hold the original path & new directory
    std::string originalPath; std::string newFileName;
    //look for last appearanc of forward slash
    std::size_t found = path.find_last_of('/');
    //last appearance of forward-slash represents the last char of string
    if(found == path.length()-1)
    {
        //var to represent appended string if there is slash at the end
        std::string poppedBackPath;
        poppedBackPath = path;
        poppedBackPath.pop_back();
        found = poppedBackPath.find_last_of('/');
        //checker for if found location of slash is first char (aka root)
        if(found == 0)
        {
            originalPath = "/";
            newFileName = poppedBackPath.substr(1);
        }
        else
        {
            originalPath = poppedBackPath.substr(0,found);
            newFileName = poppedBackPath.substr(found+1);
        }
    }
    //last appearence of forward-slash preceded the new directory name
    else
    {
        originalPath = path.substr(0,found);
        newFileName = path.substr(found+1);
    }
    //if original path is empty, make it root directory
    if(originalPath.length() == 0)
    {
        originalPath = "/";
    }

    //EARLY RETURNS (part2)
    //return early if name is map directory or contains name space directory characteristics
    if(mapDirectoryChecker(newFileName))
    {
        return;
    }
    else if(nameStartDirectoryChecker(newFileName))
    {
        return;
    }
    else if(nameEndDirectoryChecker(newFileName))
    {
        return;
    }
    //returns early if name is too long
    if(newFileName.length() > 8)
    {
        return;
    }

    //SECTION 2: LOCATE THE POSITION TO START WRITING NEW FILE DESCRIPTOR

    //2A: Prepare variables.

    //load the currentNode with the directory that will hold the new directory
    bool success = loadPathNode(originalPath);
    if(!success)
    {
        return;
    }
    //position indicator for fstream
    int position;

    //2B: Search through nodes to find starting position.

    //find the last child of the parent directory
    currentDirectory = currentNode;
    //if the current directory has children... 
    if(currentDirectory->children.size() > 0)
    {
        //set the current node to the last child in the current directory.
        currentNode = currentDirectory->children.back();
        //and if the last child is a name space directory...
        if(currentNode->nameStartDir)
        {
            //...set the current position equal to the end of the _END offset location
            position = currentNode->_ENDOffsetLoc;
        }
        else
        {
            //...else set it equal to the next descriptor offset location
            position = currentNode->indiNextDescOffset;
        }
    }
    //else if the current directory is empty...
    else
    {
        //set the position equal to the next descriptor offset, b/c...
        //...the next directory will become a child of the current directory
        position = currentDirectory->indiNextDescOffset;
    }

    //SECTION 3: RECORD EVERYTHING FROM POSITION TO END OF THE FILE

    //go to starting position in file
    file.seekg(position, std::ios::beg);
    //calculate the descriptor number we are about to start the copy at
    int descNum = (position - descOff)/16;
    //subtract number of descriptors from next descriptor number
    int difference = numDesc - descNum;
    //calculate the number of bytes required to be copied by mult. this number by 16
    int bytesToCopy = difference * 16;
    //create buffer to store copied data
    char descBuffer[bytesToCopy];
    if(bytesToCopy > 0)
    {
        file.read(descBuffer, bytesToCopy);
    }

    //SECTION 4: WRITE STIUFF

    //4A: Write new file descriptor.

    //set write position
    file.seekp(position, std::ios::beg);
    //create string for file name
    char nameChar[9];
    nameChar[8] = '\0';
    strcpy(nameChar, newFileName.c_str());
    //create lump offset and length fillers; set to zero for each
    uint32_t zeros = 0;
    //write the lump offset, size and name for the new descriptor
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(reinterpret_cast<const char*>(&zeros), 4);
    file.write(newFileName.c_str(), 8);

    //4B: Write back old content.

    //write back the old content
    if(bytesToCopy > 0)
    {
        file.write(descBuffer, bytesToCopy);
    }

    //SECTION 4: UPDATE MEMBERS

    //update the descriptor amount by adding 1
    file.seekp(4, std::ios::beg);
    uint32_t newNumberOfDescriptors = numDesc + 1;
    file.write(reinterpret_cast<const char*>(&newNumberOfDescriptors), 4);
    //update each descriptor located after the newly added descriptors
    root = nullptr;
    updateWadTree(wadPath);




}

//If given a valid path to an empty file, augments file size and generates a lump offset, then writes length amount
//of bytes from the buffer into the file’s lump data. If offset is provided, data should be written starting from that
//byte in the lump content. Returns number of bytes copied from buffer, or -1 if path does not represent content
//(e.g., if it represents a directory). 
int Wad::writeToFile(const std::string &path, const char *buffer, int length, int offset)
{
    //return early if empty string passed through
    if(!pathChecker(path))
    {
        return -1;
    }
    //return early if just the root directory passed through
    if(path == "/")
    {
        return -1;
    }

    //SECTION 1: VERIFY FILE IS EMPTY AND AVAILABLE

    //return early if element loaded from path is not content
    if(!isContent(path))
    {
        return -1;
    }
    //load the currentNode with the directory that will hold the new directory
    bool success = loadPathNode(path);
    if(!success)
    {
        return -1;
    }
    //return early if element does not have lump offset and size equal to zero
    if(currentNode->lumpOffset != 0 || currentNode->lumpLength != 0)
    {
        return 0;
    }

    //SECTION 2: PREPARE THE NEW CONTENT THAT WILL BE WRITTEN
    
    //todo: length and offset checking?

    //copy the specificed buffer using length and offset specifications
    char lumpContent[length+1];
    lumpContent[length] = '\0';
    int j = 0;
    for(int i = offset; i < length+offset; i++)
    {
        lumpContent[j] = buffer[i];
        j++;
    }

    //SECTION 3: COPY EVERYING FROM BEGINNING OF DESCRIPTORS

    //go to starting position (beginning of descriptors)
    file.seekg(descOff, std::ios::beg);
    //variable storing the number of bytes to copy
    int bytesToCopy = numDesc * 16;
    //create buffer to store copied data
    char descBuffer[bytesToCopy];
    //read and store the contents from beginning of descriptor list to end of file
    file.read(descBuffer, bytesToCopy);

    //SECTION 4: WRITE THE NEW CONTENT, STARTING AT THE PREVIOUS END OF LUMP DATA

    //go to starting position (beginning of descriptors)
    file.seekp(descOff, std::ios::beg);
    //write the new lump data for the file
    file.write(lumpContent, length);

    //SECTION 5: WRITE BACK THE DESCRIPTOR LIST

    //continue at current file writing position, sitting at the end..
    //..of the newly written lump data
    file.write(descBuffer, bytesToCopy);

    //SECTION 6: UPDATE DESCRIPTOR OFFSET, FILE DESCRIPTOR & TREE

    //6A: Write new descriptor offset value in file header

    //record old descriptor offset (will be used to represent starting position of file lump offset)
    uint32_t oldDescOff = descOff;
    //update member variable for descOff
    descOff = descOff + length;
    //set write position to starting location of header descriptor offset
    file.seekp(8, std::ios::beg);
    //write the new descriptor offset
    file.write(reinterpret_cast<const char*>(&descOff), 4);

    //6B: Write new element offset and length in file descriptor
    
    //record file descritptor offset location by subtracting 16 from the next descriptor location it points to
    uint32_t fileDescOff = length + (currentNode->indiNextDescOffset - 16);
    //record length as 4 byte variabke
    uint32_t fourByteLength = length;
    //set write position to file descritptor offset
    file.seekp(fileDescOff, std::ios::beg);
    //write new element offset and element length
    file.write(reinterpret_cast<const char*>(&oldDescOff), 4);
    file.write(reinterpret_cast<const char*>(&fourByteLength), 4);

    //6C: Update new n-ary tree by reading from file
    root = nullptr;
    updateWadTree(wadPath);

    return length;

}
